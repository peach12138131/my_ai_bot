from flask import Flask, request, jsonify, Response, stream_with_context, send_from_directory, session
import os
from dotenv import load_dotenv
from services.claude_service import query_claude_stream, query_claude_with_code_execution
from services.session_manager import session_manager
from services.files_service import create_files_service
from services.database import db_manager
import json
import secrets
from functools import wraps

load_dotenv()

app = Flask(__name__, static_folder='../frontend/static', static_url_path='/static')
app.secret_key = 'my-secret-key-for-testing-123456'
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_NAME'] = 'ai_session'

USERNAME = "tt"
PASSWORD = "4443@2148"

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return jsonify({'error': '未登录'}), 401
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET'])
def login_page():
    return send_from_directory('../frontend', 'login.html')

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    
    if username == USERNAME and password == PASSWORD:
        session['logged_in'] = True
        session['user_id'] = username
        session.permanent = True
        print(f"登录成功，设置session: {session.get('logged_in')}")
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': '用户名或密码错误'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.pop('logged_in', None)
    return jsonify({'success': True})

@app.route('/api/check_auth', methods=['GET'])
def check_auth():
    return jsonify({'logged_in': session.get('logged_in', False)})

@app.route('/')
def index():
    logged_in = session.get('logged_in', False)
    print(f"访问首页，session状态: {logged_in}, session内容: {dict(session)}")
    if not logged_in:
        return send_from_directory('../frontend', 'login.html')
    return send_from_directory('../frontend', 'index.html')

@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id', '')
        
        if not user_message:
            return jsonify({'error': '消息不能为空'}), 400
        
        user_id = session.get('user_id', 'default_user')
        
        if not session_id:
            session_id = session_manager.create_session(user_id)
        
        chat_session = session_manager.get_session(session_id)
        if not chat_session:
            return jsonify({'error': '会话不存在'}), 404
        
        session_manager.add_message(session_id, 'user', user_message)
        
        api_key = os.getenv("CLAUDE_API_KEY")
        base_url = os.getenv("CLAUDE_BASE_URL", "https://api.anthropic.com/v1")
        model = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5-20250929")
        
        if not api_key:
            return jsonify({'error': 'API Key 未配置'}), 500
        
        history = session_manager.get_messages(session_id)
        
        session_files = db_manager.get_session_files(session_id)
        file_ids = [f['anthropic_file_id'] for f in session_files] if session_files else []
        
        container_id = chat_session.get('container_id')
        
        def generate():
            try:
                full_response = ""
                new_container_id = None
                
                if file_ids:
                    for chunk_type, content, returned_container_id in query_claude_with_code_execution(
                        messages=history,
                        api_key=api_key,
                        file_ids=file_ids,
                        container_id=container_id,
                        base_url=base_url,
                        model=model
                    ):
                        if chunk_type == 'text':
                            full_response += content
                            yield f"data: {json.dumps({'type': 'chunk', 'content': content})}\n\n"
                        elif chunk_type == 'tool_use':
                            yield f"data: {json.dumps({'type': 'tool_use', 'content': content})}\n\n"
                        elif chunk_type == 'tool_result':
                            full_response += content
                            yield f"data: {json.dumps({'type': 'tool_result', 'content': content})}\n\n"
                        elif chunk_type == 'end':
                            new_container_id = returned_container_id
                        elif chunk_type == 'error':
                            yield f"data: {json.dumps({'type': 'error', 'content': content})}\n\n"
                            return
                else:
                    for chunk in query_claude_stream(
                        messages=history,
                        api_key=api_key,
                        base_url=base_url,
                        model=model
                    ):
                        full_response += chunk
                        yield f"data: {json.dumps({'type': 'chunk', 'content': chunk})}\n\n"
                
                session_manager.add_message(session_id, 'assistant', full_response)
                
                if new_container_id:
                    db_manager.update_container_id(session_id, new_container_id)
                
                yield f"data: {json.dumps({'type': 'end', 'content': '', 'session_id': session_id})}\n\n"
                
            except Exception as e:
                yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"
        
        return Response(
            stream_with_context(generate()),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no'
            }
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok'})

@app.route('/api/sessions', methods=['GET'])
@login_required
def get_sessions():
    user_id = session.get('user_id', 'default_user')
    sessions = session_manager.get_user_sessions(user_id)
    return jsonify({'sessions': sessions})

@app.route('/api/sessions', methods=['POST'])
@login_required
def create_session():
    user_id = session.get('user_id', 'default_user')
    data = request.get_json() or {}
    title = data.get('title', '新对话')
    
    session_id = session_manager.create_session(user_id, title)
    return jsonify({'session_id': session_id, 'success': True})

@app.route('/api/sessions/<session_id>', methods=['DELETE'])
@login_required
def delete_session(session_id):
    user_id = session.get('user_id', 'default_user')
    success = session_manager.delete_session(session_id, user_id)
    return jsonify({'success': success})

@app.route('/api/sessions/<session_id>/messages', methods=['GET'])
@login_required
def get_session_messages(session_id):
    messages = session_manager.get_messages(session_id)
    return jsonify({'messages': messages})

@app.route('/api/sessions/<session_id>/title', methods=['PUT'])
@login_required
def update_session_title(session_id):
    data = request.get_json()
    title = data.get('title', '')
    success = session_manager.update_session_title(session_id, title)
    return jsonify({'success': success})

@app.route('/api/files/upload', methods=['POST'])
@login_required
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': '没有文件'}), 400
        
        file = request.files['file']
        session_id = request.form.get('session_id', '')
        
        if not session_id:
            return jsonify({'error': '会话ID不能为空'}), 400
        
        if file.filename == '':
            return jsonify({'error': '文件名为空'}), 400
        
        api_key = os.getenv("CLAUDE_API_KEY")
        base_url = os.getenv("CLAUDE_BASE_URL", "https://api.anthropic.com/v1")
        
        if not api_key:
            return jsonify({'error': 'API Key 未配置'}), 500
        
        files_service = create_files_service(api_key, base_url)
        
        file_content = file.read()
        file_size = len(file_content)
        
        result = files_service.upload_file(
            file_path=file.filename,
            file_content=file_content,
            filename=file.filename
        )
        
        if not result:
            return jsonify({'error': '文件上传失败'}), 500
        
        file_id = db_manager.add_file(
            session_id=session_id,
            filename=file.filename,
            anthropic_file_id=result['file_id'],
            file_size=file_size
        )
        
        if not file_id:
            return jsonify({'error': '保存文件信息失败'}), 500
        
        return jsonify({
            'success': True,
            'file_id': file_id,
            'anthropic_file_id': result['file_id'],
            'filename': file.filename,
            'size': file_size
        })
        
    except Exception as e:
        print(f"Error in upload_file: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/sessions/<session_id>/files', methods=['GET'])
@login_required
def get_session_files(session_id):
    try:
        files = db_manager.get_session_files(session_id)
        return jsonify({'files': files})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/files/<int:file_id>', methods=['DELETE'])
@login_required
def delete_file_endpoint(file_id):
    try:
        session_id = request.args.get('session_id', '')
        
        if not session_id:
            return jsonify({'error': '会话ID不能为空'}), 400
        
        success = db_manager.delete_file(file_id, session_id)
        return jsonify({'success': success})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8300, debug=True, threaded=True)
