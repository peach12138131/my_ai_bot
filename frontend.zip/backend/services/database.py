import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Optional
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'database', 'sessions.db')

def init_database():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            container_id TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id)
    ''')
    
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_messages_session_id ON messages(session_id)
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            anthropic_file_id TEXT NOT NULL,
            upload_time TEXT NOT NULL,
            file_size INTEGER,
            FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_files_session_id ON files(session_id)
    ''')
    
    try:
        cursor.execute('ALTER TABLE sessions ADD COLUMN container_id TEXT')
    except sqlite3.OperationalError:
        pass
    
    conn.commit()
    conn.close()

class DatabaseManager:
    def __init__(self):
        init_database()
    
    def _get_connection(self):
        return sqlite3.connect(DB_PATH)
    
    def create_session(self, session_id: str, user_id: str, title: str = "新对话") -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            now = datetime.now().isoformat()
            cursor.execute(
                'INSERT INTO sessions (id, user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
                (session_id, user_id, title, now, now)
            )
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error creating session: {e}")
            return False
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'SELECT id, user_id, title, created_at, updated_at, container_id FROM sessions WHERE id = ?',
                (session_id,)
            )
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return {
                    'id': row[0],
                    'user_id': row[1],
                    'title': row[2],
                    'created_at': row[3],
                    'updated_at': row[4],
                    'container_id': row[5]
                }
            return None
        except Exception as e:
            print(f"Error getting session: {e}")
            return None
    
    def get_user_sessions(self, user_id: str) -> List[Dict]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                '''SELECT s.id, s.title, s.created_at, s.updated_at, COUNT(m.id) as message_count
                   FROM sessions s
                   LEFT JOIN messages m ON s.id = m.session_id
                   WHERE s.user_id = ?
                   GROUP BY s.id
                   ORDER BY s.updated_at DESC''',
                (user_id,)
            )
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'id': row[0],
                    'title': row[1],
                    'created_at': row[2],
                    'updated_at': row[3],
                    'message_count': row[4]
                }
                for row in rows
            ]
        except Exception as e:
            print(f"Error getting user sessions: {e}")
            return []
    
    def add_message(self, session_id: str, role: str, content: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            now = datetime.now().isoformat()
            
            cursor.execute(
                'INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)',
                (session_id, role, content, now)
            )
            
            cursor.execute(
                'UPDATE sessions SET updated_at = ? WHERE id = ?',
                (now, session_id)
            )
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error adding message: {e}")
            return False
    
    def get_messages(self, session_id: str) -> List[Dict]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'SELECT role, content, timestamp FROM messages WHERE session_id = ? ORDER BY timestamp ASC',
                (session_id,)
            )
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'role': row[0],
                    'content': row[1],
                    'timestamp': row[2]
                }
                for row in rows
            ]
        except Exception as e:
            print(f"Error getting messages: {e}")
            return []
    
    def delete_session(self, session_id: str, user_id: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'SELECT user_id FROM sessions WHERE id = ?',
                (session_id,)
            )
            row = cursor.fetchone()
            
            if not row or row[0] != user_id:
                conn.close()
                return False
            
            cursor.execute('DELETE FROM messages WHERE session_id = ?', (session_id,))
            cursor.execute('DELETE FROM sessions WHERE id = ?', (session_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error deleting session: {e}")
            return False
    
    def update_session_title(self, session_id: str, title: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            now = datetime.now().isoformat()
            cursor.execute(
                'UPDATE sessions SET title = ?, updated_at = ? WHERE id = ?',
                (title, now, session_id)
            )
            
            conn.commit()
            conn.close()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"Error updating session title: {e}")
            return False
    
    def clear_session_messages(self, session_id: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM messages WHERE session_id = ?', (session_id,))
            
            now = datetime.now().isoformat()
            cursor.execute(
                'UPDATE sessions SET updated_at = ? WHERE id = ?',
                (now, session_id)
            )
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error clearing session messages: {e}")
            return False
    
    def update_container_id(self, session_id: str, container_id: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'UPDATE sessions SET container_id = ? WHERE id = ?',
                (container_id, session_id)
            )
            
            conn.commit()
            conn.close()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"Error updating container_id: {e}")
            return False
    
    def add_file(self, session_id: str, filename: str, anthropic_file_id: str, file_size: int = 0) -> Optional[int]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            now = datetime.now().isoformat()
            cursor.execute(
                'INSERT INTO files (session_id, filename, anthropic_file_id, upload_time, file_size) VALUES (?, ?, ?, ?, ?)',
                (session_id, filename, anthropic_file_id, now, file_size)
            )
            
            file_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return file_id
        except Exception as e:
            print(f"Error adding file: {e}")
            return None
    
    def get_session_files(self, session_id: str) -> List[Dict]:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'SELECT id, filename, anthropic_file_id, upload_time, file_size FROM files WHERE session_id = ? ORDER BY upload_time DESC',
                (session_id,)
            )
            
            rows = cursor.fetchall()
            conn.close()
            
            return [
                {
                    'id': row[0],
                    'filename': row[1],
                    'anthropic_file_id': row[2],
                    'upload_time': row[3],
                    'file_size': row[4]
                }
                for row in rows
            ]
        except Exception as e:
            print(f"Error getting session files: {e}")
            return []
    
    def delete_file(self, file_id: int, session_id: str) -> bool:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                'DELETE FROM files WHERE id = ? AND session_id = ?',
                (file_id, session_id)
            )
            
            conn.commit()
            conn.close()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"Error deleting file: {e}")
            return False

db_manager = DatabaseManager()
