import requests
from typing import Optional, Dict
import os

class FilesService:
    def __init__(self, api_key: str, base_url: str = "https://api.anthropic.com/v1"):
        self.api_key = api_key
        self.base_url = base_url
        self.files_url = f"{base_url}/files"
    
    def upload_file(self, file_path: str, file_content: bytes, filename: str) -> Optional[Dict]:
        """
        上传文件到Anthropic Files API
        
        Args:
            file_path: 文件路径（用于获取文件类型）
            file_content: 文件内容（字节）
            filename: 文件名
            
        Returns:
            Dict: 包含file_id和其他元数据，或None如果失败
        """
        try:
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "files-api-2025-04-14"
            }
            
            files = {
                'file': (filename, file_content, 'application/octet-stream')
            }
            
            response = requests.post(
                self.files_url,
                headers=headers,
                files=files
            )
            
            print(f"Files API Response Status: {response.status_code}")
            print(f"Files API Response: {response.text}")
            
            response.raise_for_status()
            data = response.json()
            
            return {
                'file_id': data.get('id'),
                'filename': data.get('filename'),
                'size': data.get('size_bytes', 0),
                'created_at': data.get('created_at')
            }
            
        except requests.exceptions.RequestException as e:
            print(f"Error uploading file: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response content: {e.response.text}")
            return None
    
    def get_file_info(self, file_id: str) -> Optional[Dict]:
        """
        获取文件元数据
        
        Args:
            file_id: Anthropic文件ID
            
        Returns:
            Dict: 文件元数据
        """
        try:
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "files-api-2025-04-14"
            }
            
            response = requests.get(
                f"{self.files_url}/{file_id}",
                headers=headers
            )
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            print(f"Error getting file info: {e}")
            return None
    
    def delete_file(self, file_id: str) -> bool:
        """
        删除文件
        
        Args:
            file_id: Anthropic文件ID
            
        Returns:
            bool: 是否成功删除
        """
        try:
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "files-api-2025-04-14"
            }
            
            response = requests.delete(
                f"{self.files_url}/{file_id}",
                headers=headers
            )
            
            response.raise_for_status()
            return True
            
        except requests.exceptions.RequestException as e:
            print(f"Error deleting file: {e}")
            return False

def create_files_service(api_key: str, base_url: str = "https://api.anthropic.com/v1") -> FilesService:
    return FilesService(api_key, base_url)
