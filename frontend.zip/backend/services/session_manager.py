from typing import List, Dict, Optional
import uuid
from .database import db_manager

class SessionManager:
    def __init__(self):
        self.db = db_manager
    
    def create_session(self, user_id: str, title: str = "新对话") -> str:
        session_id = str(uuid.uuid4())
        self.db.create_session(session_id, user_id, title)
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict]:
        return self.db.get_session(session_id)
    
    def get_user_sessions(self, user_id: str) -> List[Dict]:
        return self.db.get_user_sessions(user_id)
    
    def add_message(self, session_id: str, role: str, content: str) -> bool:
        return self.db.add_message(session_id, role, content)
    
    def get_messages(self, session_id: str) -> List[Dict]:
        return self.db.get_messages(session_id)
    
    def delete_session(self, session_id: str, user_id: str) -> bool:
        return self.db.delete_session(session_id, user_id)
    
    def update_session_title(self, session_id: str, title: str) -> bool:
        return self.db.update_session_title(session_id, title)
    
    def clear_session_messages(self, session_id: str) -> bool:
        return self.db.clear_session_messages(session_id)

session_manager = SessionManager()
