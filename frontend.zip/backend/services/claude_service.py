import requests
import json
from typing import Generator, List, Dict, Union, Optional, Tuple

def query_claude_stream(messages: Union[str, List[Dict]], 
                       api_key: str, 
                       base_url: str = "https://api.anthropic.com/v1", 
                       model: str = "claude-sonnet-4-5-20250929", 
                       max_tokens: int = 4096, 
                       temperature: float = 0.7) -> Generator[str, None, None]:
    """
    流式调用 Claude API，返回文本片段
    """
    url = f"{base_url}/messages"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01"
    }
    
    if isinstance(messages, str):
        formatted_messages = [{"role": "user", "content": messages}]
    else:
        formatted_messages = [
            {"role": msg["role"], "content": msg["content"]} 
            for msg in messages 
            if msg["role"] in ["user", "assistant"]
        ]
    
    payload = {
        "model": model,
        "messages": formatted_messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": True
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, stream=True)
        response.raise_for_status()
        
        for line in response.iter_lines():
            if line:
                line_text = line.decode('utf-8')
                
                if not line_text.startswith('data: '):
                    continue
                
                json_str = line_text[6:]
                
                if json_str == '[DONE]':
                    break
                
                try:
                    event_data = json.loads(json_str)
                    
                    if event_data.get('type') == 'content_block_delta':
                        delta = event_data.get('delta', {})
                        if delta.get('type') == 'text_delta':
                            text_chunk = delta.get('text', '')
                            if text_chunk:
                                yield text_chunk
                                
                except json.JSONDecodeError:
                    continue
                    
    except requests.exceptions.RequestException as e:
        yield f"\n\n[错误: API 请求失败 - {str(e)}]"

def query_claude_with_code_execution(
    messages: Union[str, List[Dict]], 
    api_key: str,
    file_ids: List[str] = None,
    container_id: Optional[str] = None,
    base_url: str = "https://api.anthropic.com/v1", 
    model: str = "claude-sonnet-4-5-20250929", 
    max_tokens: int = 4096, 
    temperature: float = 0.7
) -> Generator[Tuple[str, str, Optional[str]], None, None]:
    """
    流式调用 Claude API with Code Execution工具
    
    Args:
        messages: 消息列表或单个消息字符串
        api_key: API密钥
        file_ids: Anthropic文件ID列表
        container_id: 容器ID（可选，用于重用容器）
        base_url: API基础URL
        model: 模型名称
        max_tokens: 最大token数
        temperature: 温度参数
        
    Yields:
        Tuple[str, str, Optional[str]]: (chunk_type, content, container_id)
            chunk_type: 'text' | 'tool_use' | 'tool_result' | 'end'
            content: 文本内容或工具调用信息
            container_id: 新的容器ID（仅在end时返回）
    """
    url = f"{base_url}/messages"
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "code-execution-2025-08-25,files-api-2025-04-14"
    }
    
    if isinstance(messages, str):
        user_content = [{"type": "text", "text": messages}]
        if file_ids:
            for file_id in file_ids:
                user_content.append({"type": "container_upload", "file_id": file_id})
        formatted_messages = [{"role": "user", "content": user_content}]
    else:
        formatted_messages = []
        for msg in messages:
            if msg["role"] in ["user", "assistant"]:
                if msg["role"] == "user" and file_ids and msg == messages[-1]:
                    content = [{"type": "text", "text": msg["content"]}]
                    for file_id in file_ids:
                        content.append({"type": "container_upload", "file_id": file_id})
                    formatted_messages.append({"role": "user", "content": content})
                else:
                    formatted_messages.append({"role": msg["role"], "content": msg["content"]})
    
    payload = {
        "model": model,
        "messages": formatted_messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": True,
        "tools": [{
            "type": "code_execution_20250825",
            "name": "code_execution"
        }]
    }
    
    if container_id:
        payload["container"] = container_id
    
    try:
        response = requests.post(url, headers=headers, json=payload, stream=True)
        response.raise_for_status()
        
        current_container_id = container_id
        
        for line in response.iter_lines():
            if line:
                line_text = line.decode('utf-8')
                
                if not line_text.startswith('data: '):
                    continue
                
                json_str = line_text[6:]
                
                if json_str == '[DONE]':
                    break
                
                try:
                    event_data = json.loads(json_str)
                    event_type = event_data.get('type')
                    
                    if event_type == 'content_block_delta':
                        delta = event_data.get('delta', {})
                        if delta.get('type') == 'text_delta':
                            text_chunk = delta.get('text', '')
                            if text_chunk:
                                yield ('text', text_chunk, None)
                    
                    elif event_type == 'content_block_start':
                        content_block = event_data.get('content_block', {})
                        if content_block.get('type') == 'server_tool_use':
                            tool_name = content_block.get('name', '')
                            yield ('tool_use', f"[使用工具: {tool_name}]", None)
                    
                    elif event_type == 'bash_code_execution_tool_result':
                        tool_content = event_data.get('content', {})
                        if tool_content.get('type') == 'bash_code_execution_result':
                            stdout = tool_content.get('stdout', '')
                            stderr = tool_content.get('stderr', '')
                            return_code = tool_content.get('return_code', 0)
                            
                            result_text = ""
                            if stdout:
                                result_text += f"\n输出:\n{stdout}"
                            if stderr:
                                result_text += f"\n错误:\n{stderr}"
                            if return_code != 0:
                                result_text += f"\n返回码: {return_code}"
                            
                            if result_text:
                                yield ('tool_result', result_text, None)
                    
                    elif event_type == 'text_editor_code_execution_tool_result':
                        tool_content = event_data.get('content', {})
                        if tool_content.get('type') == 'text_editor_code_execution_result':
                            yield ('tool_result', "[文件操作完成]", None)
                    
                    elif event_type == 'message_start':
                        message_data = event_data.get('message', {})
                        if 'container' in message_data:
                            current_container_id = message_data['container'].get('id')
                    
                    elif event_type == 'message_stop':
                        yield ('end', '', current_container_id)
                        
                except json.JSONDecodeError:
                    continue
                    
    except requests.exceptions.RequestException as e:
        yield ('error', f"\n\n[错误: API 请求失败 - {str(e)}]", None)