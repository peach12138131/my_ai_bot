const loginForm = document.getElementById('loginForm');
const loginBtn = document.getElementById('loginBtn');
const errorMessage = document.getElementById('errorMessage');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = usernameInput.value.trim();
    const password = passwordInput.value;
    
    if (!username || !password) {
        showError('请输入用户名和密码');
        return;
    }
    
    loginBtn.disabled = true;
    loginBtn.textContent = '登录中...';
    errorMessage.textContent = '';
    
    try {
        console.log('发送登录请求...');
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password })
        });
        
        console.log('响应状态:', response.status);
        const data = await response.json();
        console.log('响应数据:', data);
        
        if (response.ok && data.success) {
            console.log('登录成功，即将跳转...');
            console.log('Response headers:', response.headers);
            window.location.replace('/');
        } else {
            console.log('登录失败:', data.error);
            showError(data.error || '登录失败，请重试');
            loginBtn.disabled = false;
            loginBtn.textContent = '登录';
        }
    } catch (error) {
        console.error('登录错误:', error);
        showError('网络错误：' + error.message);
        loginBtn.disabled = false;
        loginBtn.textContent = '登录';
    }
});

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
}

passwordInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        loginForm.dispatchEvent(new Event('submit'));
    }
});
