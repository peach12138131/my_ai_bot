// DOM 元素
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const clearBtn = document.getElementById('clearBtn');
const newSessionBtn = document.getElementById('newSessionBtn');
const sessionList = document.getElementById('sessionList');
const uploadBtn = document.getElementById('uploadBtn');
const fileInput = document.getElementById('fileInput');
const filesList = document.getElementById('filesList');

// API 配置
const API_URL = '/api/chat';
const SESSIONS_URL = '/api/sessions';
const FILES_URL = '/api/files';

let currentSessionId = null;
let sessions = [];
let sessionFiles = [];

async function checkAuth() {
    try {
        const response = await fetch('/api/check_auth');
        const data = await response.json();
        if (!data.logged_in) {
            window.location.href = '/login';
        }
    } catch (error) {
        console.error('认证检查失败:', error);
        window.location.href = '/login';
    }
}

checkAuth();
loadSessions();

// 发送消息
async function sendMessage() {
    const message = userInput.value.trim();

    if (!message) return;

    // 清空输入框
    userInput.value = '';
    userInput.style.height = 'auto';

    // 移除欢迎消息
    const welcomeMsg = document.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }

    // 显示用户消息
    appendMessage('user', message);

    // 禁用发送按钮
    sendBtn.disabled = true;
    const sendingSvg = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" opacity="0.25"/><path d="M12 2 A10 10 0 0 1 22 12" stroke-linecap="round"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/></path></svg>';
    sendBtn.innerHTML = sendingSvg;

    // 创建 AI 消息容器
    const aiMessageDiv = createMessageElement('ai', '');
    const aiContentDiv = aiMessageDiv.querySelector('.message-content');

    // 显示打字指示器
    aiContentDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
    chatMessages.appendChild(aiMessageDiv);
    scrollToBottom();

    try {
        // 发送请求
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                message: message,
                session_id: currentSessionId 
            })
        });

        if (!response.ok) {
            throw new Error('网络请求失败');
        }

        // 处理流式响应
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let aiResponse = '';

        // 移除打字指示器
        aiContentDiv.innerHTML = '';

        while (true) {
            const { done, value } = await reader.read();

            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));

                        if (data.type === 'chunk') {
                            aiResponse += data.content;
                            aiContentDiv.innerHTML = marked.parse(aiResponse);
                            scrollToBottom();
                        } else if (data.type === 'tool_use') {
                            const toolDiv = document.createElement('div');
                            toolDiv.className = 'tool-use-indicator';
                            toolDiv.textContent = data.content;
                            aiContentDiv.appendChild(toolDiv);
                            scrollToBottom();
                        } else if (data.type === 'tool_result') {
                            const resultDiv = document.createElement('pre');
                            resultDiv.className = 'tool-result';
                            resultDiv.textContent = data.content;
                            aiContentDiv.appendChild(resultDiv);
                            scrollToBottom();
                        } else if (data.type === 'end') {
                            console.log('流式传输完成');
                            if (data.session_id) {
                                currentSessionId = data.session_id;
                                console.log('当前会话ID:', currentSessionId);
                                loadSessions();
                            }
                        } else if (data.type === 'error') {
                            aiContentDiv.textContent = `错误: ${data.content}`;
                        }
                    } catch (e) {
                        console.error('解析数据出错:', e);
                    }
                }
            }
        }

    } catch (error) {
        console.error('请求错误:', error);
        aiContentDiv.textContent = '抱歉，发生了错误。请稍后重试。';
    } finally {
        // 恢复发送按钮
        sendBtn.disabled = false;
        sendBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>';
    }
}

// 创建消息元素
function createMessageElement(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = role === 'user' ? 'USER' : 'AI';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    if (role === 'ai' && typeof marked !== 'undefined') {
        contentDiv.innerHTML = marked.parse(content);
    } else {
        contentDiv.textContent = content;
    }

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);

    return messageDiv;
}

// 添加消息
function appendMessage(role, content) {
    const messageDiv = createMessageElement(role, content);
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// 滚动到底部
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// 清空对话
function clearChat() {
    currentSessionId = null;
    sessionFiles = [];
    updateFilesListUI();
    chatMessages.innerHTML = `
        <div class="welcome-message">
            <div class="welcome-icon"></div>
            <h2>ADVANCED AI SYSTEM</h2>
            <p>下一代智能对话系统 | 强大 · 高效 · 精准</p>
            <div class="welcome-features">
                <div class="feature-item">
                    <span class="feature-icon">ANALYSIS</span>
                    <span>智能分析</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">INSIGHT</span>
                    <span>深度洞察</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">SOLUTION</span>
                    <span>高效解决</span>
                </div>
            </div>
        </div>
    `;
    updateSessionListUI();
    console.log('已清空对话，开始新会话');
}

// 加载会话列表
async function loadSessions() {
    try {
        const response = await fetch(SESSIONS_URL);
        const data = await response.json();
        sessions = data.sessions || [];
        updateSessionListUI();
    } catch (error) {
        console.error('加载会话列表失败:', error);
    }
}

// 格式化时间
function formatDateTime(isoString) {
    const date = new Date(isoString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}`;
}

// 更新会话列表UI
function updateSessionListUI() {
    if (sessions.length === 0) {
        sessionList.innerHTML = '<div class="session-empty">暂无对话</div>';
        return;
    }
    
    sessionList.innerHTML = sessions.map(session => `
        <div class="session-item ${session.id === currentSessionId ? 'active' : ''}" data-session-id="${session.id}">
            <div class="session-item-title">${session.title}</div>
            <div class="session-item-info">
                <span>${session.message_count} 条消息</span>
                <span class="session-item-time">${formatDateTime(session.updated_at)}</span>
            </div>
            <button class="session-item-delete" data-session-id="${session.id}">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
    `).join('');
    
    // 绑定会话点击事件
    document.querySelectorAll('.session-item').forEach(item => {
        item.addEventListener('click', (e) => {
            if (!e.target.closest('.session-item-delete')) {
                const sessionId = item.dataset.sessionId;
                switchSession(sessionId);
            }
        });
    });
    
    // 绑定删除按钮事件
    document.querySelectorAll('.session-item-delete').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const sessionId = btn.dataset.sessionId;
            await deleteSession(sessionId);
        });
    });
}

// 切换会话
async function switchSession(sessionId) {
    try {
        currentSessionId = sessionId;
        updateSessionListUI();
        
        // 加载会话消息
        const response = await fetch(`${SESSIONS_URL}/${sessionId}/messages`);
        const data = await response.json();
        
        // 清空并重新渲染消息
        chatMessages.innerHTML = '';
        
        if (data.messages && data.messages.length > 0) {
            data.messages.forEach(msg => {
                appendMessage(msg.role, msg.content);
            });
        } else {
            chatMessages.innerHTML = `
                <div class="welcome-message">
                    <div class="welcome-icon"></div>
                    <h2>ADVANCED AI SYSTEM</h2>
                    <p>下一代智能对话系统 | 强大 · 高效 · 精准</p>
                </div>
            `;
        }
        
        await loadSessionFiles();
        scrollToBottom();
    } catch (error) {
        console.error('切换会话失败:', error);
    }
}

// 新建会话
async function createNewSession() {
    try {
        const response = await fetch(SESSIONS_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title: '新对话' })
        });
        
        const data = await response.json();
        if (data.success) {
            await loadSessions();
            currentSessionId = data.session_id;
            clearChat();
        }
    } catch (error) {
        console.error('创建新会话失败:', error);
    }
}

// 删除会话
async function deleteSession(sessionId) {
    try {
        const response = await fetch(`${SESSIONS_URL}/${sessionId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        if (data.success) {
            if (currentSessionId === sessionId) {
                currentSessionId = null;
                clearChat();
            }
            await loadSessions();
        }
    } catch (error) {
        console.error('删除会话失败:', error);
    }
}

// 自动调整输入框高度
function autoResizeTextarea() {
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 150) + 'px';
}

async function logout() {
    try {
        await fetch('/api/logout', {
            method: 'POST'
        });
        window.location.href = '/login';
    } catch (error) {
        console.error('退出登录失败:', error);
    }
}

// 事件监听
async function loadSessionFiles() {
    if (!currentSessionId) {
        sessionFiles = [];
        updateFilesListUI();
        return;
    }
    
    try {
        const response = await fetch(`${SESSIONS_URL}/${currentSessionId}/files`);
        const data = await response.json();
        sessionFiles = data.files || [];
        updateFilesListUI();
    } catch (error) {
        console.error('加载文件列表失败:', error);
    }
}

function updateFilesListUI() {
    if (sessionFiles.length === 0) {
        filesList.innerHTML = '';
        filesList.style.display = 'none';
        return;
    }
    
    filesList.style.display = 'flex';
    filesList.innerHTML = sessionFiles.map(file => `
        <div class="file-item" data-file-id="${file.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                <polyline points="13 2 13 9 20 9"></polyline>
            </svg>
            <span class="file-name">${file.filename}</span>
            <button class="file-delete-btn" data-file-id="${file.id}">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
    `).join('');
    
    document.querySelectorAll('.file-delete-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const fileId = btn.dataset.fileId;
            await deleteFile(fileId);
        });
    });
}

async function uploadFile(file) {
    if (!currentSessionId) {
        alert('请先创建会话');
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('session_id', currentSessionId);
        
        const response = await fetch(`${FILES_URL}/upload`, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        if (data.success) {
            await loadSessionFiles();
        } else {
            alert('文件上传失败: ' + (data.error || '未知错误'));
        }
    } catch (error) {
        console.error('上传文件失败:', error);
        alert('上传文件失败');
    }
}

async function deleteFile(fileId) {
    try {
        const response = await fetch(`${FILES_URL}/${fileId}?session_id=${currentSessionId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        if (data.success) {
            await loadSessionFiles();
        }
    } catch (error) {
        console.error('删除文件失败:', error);
    }
}

sendBtn.addEventListener('click', sendMessage);
clearBtn.addEventListener('click', clearChat);
newSessionBtn.addEventListener('click', createNewSession);
document.getElementById('logoutBtn').addEventListener('click', logout);

uploadBtn.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files);
    for (const file of files) {
        await uploadFile(file);
    }
    fileInput.value = '';
});

userInput.addEventListener('input', () => {
    autoResizeTextarea();
    // 根据输入内容启用/禁用发送按钮
    sendBtn.disabled = !userInput.value.trim();
});

userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
        e.preventDefault();
        if (userInput.value.trim()) {
            sendMessage();
        }
    }
});

// 页面加载完成
console.log('AI 聊天应用已加载');

// 初始化发送按钮状态
sendBtn.disabled = true;