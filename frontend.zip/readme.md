创建以下目录结构：
```
my_ai_bot/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   └── services/
│       ├── __init__.py
│       └── claude_service.py
├── frontend/
│   ├── index.html
│   └── static/
│       ├── css/
│       │   └── style.css
│       └── js/
│           └── app.js
├── .env
readme.md
```